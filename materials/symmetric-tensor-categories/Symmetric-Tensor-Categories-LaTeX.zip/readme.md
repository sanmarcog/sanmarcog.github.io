# Symmetric Tensor Categories — Winter 2025

University of Washington. Instructor: Guillermo Sanmarco.
Revised edition: 31 October 2026.

Open `main.tex` as the main document. Keep `preamble.tex`, `Style/`,
`Chapters/`, and `References/` together. Compile with pdfLaTeX and BibTeX
(or `latexmk -pdf main.tex`). The project uses standard TeX Live packages.

Each lecture has its own file, `Chapters/lec1.tex` through
`Chapters/lec23.tex`. Individual chapter files are included by the main
project; they are not standalone documents. Edit the shared formatting in
`preamble.tex` and `Style/style.sty`.

The original student scribe credits are retained for Lectures 1–7 and 10.
Lectures 8, 9 and 11–23 were completed from the instructor’s handwritten
notes and list Guillermo Sanmarco as scribe. The originally unnumbered
February 5 notes are Lecture 10. The original Lecture 8 file was an empty
heading. Dates for Lectures 7–9 and 11–23 are estimates, marked “est.” in the headings.
They follow an assumed Monday/Wednesday/Friday schedule anchored to the
recorded dates, skipping the February 17 university holiday.

The revised text corrects mathematical statements, supplies missing
hypotheses and short proofs, and cites the inputs to longer classification
theorems. The final lecture distinguishes results from conjectures discussed
in the course. The course number is omitted at the instructor’s request.

`Chapters/errata.tex` records substantive mathematical corrections. All
corrections are incorporated in the revised notes; the website also offers
the errata as a separate PDF. Handwritten PDFs are not included in the
downloads or this source archive.

The website’s individual lecture PDFs are excerpts of the combined notes,
with the common bibliography appended; page and theorem numbering agree
with the complete document.
